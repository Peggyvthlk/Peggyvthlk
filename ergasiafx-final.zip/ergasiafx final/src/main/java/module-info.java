module javafx.unipi.gui {
	exports javafx.unipi.core;
	exports javafx.unipi.gui;

	requires javafx.base;
	requires javafx.controls;
	requires javafx.graphics;
}